import React, { useState, useEffect } from 'react';
import { ShieldCheck, Search, ExternalLink, AlertTriangle, Info, Upload, X, FileText, Download, Book, CheckCircle, ChevronLeft } from 'lucide-react';
import { checkPlagiarism } from '../services/geminiService';
import { saveHistoryItem } from '../services/storageService';
import { PlagiarismResult, UploadedFile, User, HistoryItem } from '../types';
import { Spinner } from './Spinner';

interface PlagiarismTabProps {
  user: User;
  initialData?: HistoryItem | null;
  onBack?: () => void;
}

export const PlagiarismTab: React.FC<PlagiarismTabProps> = ({ user, initialData, onBack }) => {
  const [activeTab, setActiveTab] = useState<'text' | 'file'>('text');
  const [text, setText] = useState('');
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PlagiarismResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isHistoryView, setIsHistoryView] = useState(false);

  useEffect(() => {
    if (initialData && initialData.type === 'PLAGIARISM') {
      setResult(initialData.data as PlagiarismResult);
      setIsHistoryView(true);
    } else {
      setResult(null);
      setIsHistoryView(false);
      setText('');
      setUploadedFile(null);
    }
  }, [initialData]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf' && file.type !== 'text/plain') {
      setError("Please upload a PDF or Text file.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      const base64Data = base64String.split(',')[1];
      
      setUploadedFile({
        name: file.name,
        type: file.type,
        data: base64Data
      });
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleCheck = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    setIsHistoryView(false);

    try {
      let data;
      let title = "Text Analysis";
      
      if (activeTab === 'file' && uploadedFile) {
        title = uploadedFile.name;
        if (uploadedFile.type === 'application/pdf') {
          data = await checkPlagiarism(uploadedFile.data, true);
        } else {
          const decodedText = atob(uploadedFile.data);
          data = await checkPlagiarism(decodedText, false);
        }
      } else if (activeTab === 'text' && text.trim()) {
        title = text.substring(0, 30) + "...";
        data = await checkPlagiarism(text, false);
      } else {
        throw new Error("Please provide text or a file to check.");
      }
      setResult(data);
      
      // Auto Save
      saveHistoryItem('PLAGIARISM', data, title, activeTab === 'file' ? uploadedFile?.name : undefined);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to check plagiarism. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = () => {
    const element = document.getElementById('report-content');
    if (!element) return;

    const opt = {
      margin: 0.5,
      filename: `PaperQuest_Report_${new Date().getTime()}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // @ts-ignore - html2pdf is loaded via CDN
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert("PDF generator not loaded. Please refresh.");
    }
  };

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'text-green-600';
      case 'B': return 'text-blue-600';
      case 'C': return 'text-orange-600';
      case 'D': return 'text-red-600';
      default: return 'text-slate-600';
    }
  };

  const getGradeBg = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-50 border-green-200';
      case 'B': return 'bg-blue-50 border-blue-200';
      case 'C': return 'bg-orange-50 border-orange-200';
      case 'D': return 'bg-red-50 border-red-200';
      default: return 'bg-slate-50 border-slate-200';
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Back Button for History View */}
      {isHistoryView && onBack && (
        <button onClick={onBack} className="mb-6 flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors">
          <ChevronLeft className="w-4 h-4" /> Back to Dashboard
        </button>
      )}

      {/* INPUT SECTION - Hide if viewing history */}
      {!isHistoryView && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-10 print:hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50">
            <h2 className="text-xl font-semibold text-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
              Originality & Reference Checker
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Analyze text against billions of web pages to generate a comprehensive Similarity Report.
            </p>
          </div>

          <div className="p-6">
            <div className="flex gap-2 mb-4 p-1 bg-slate-100 rounded-lg w-fit">
              <button
                onClick={() => setActiveTab('text')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'text' 
                    ? 'bg-white text-slate-900 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Paste Text
              </button>
              <button
                onClick={() => setActiveTab('file')}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === 'file' 
                    ? 'bg-white text-slate-900 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Upload File
              </button>
            </div>

            {activeTab === 'text' ? (
              <textarea
                className="w-full h-48 p-4 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-y font-serif text-sm leading-relaxed mb-4"
                placeholder="Paste text to check for originality..."
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
            ) : (
              <div className="h-48 border-2 border-dashed border-slate-300 rounded-lg flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors relative mb-4">
                {!uploadedFile ? (
                  <>
                    <Upload className="w-10 h-10 text-slate-400 mb-3" />
                    <p className="text-sm text-slate-600 font-medium">Click to upload PDF or Text</p>
                    <p className="text-xs text-slate-400 mt-1">Max 10MB</p>
                    <input 
                      type="file" 
                      accept=".pdf,.txt,text/plain,application/pdf"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={handleFileUpload}
                    />
                  </>
                ) : (
                  <div className="text-center p-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <FileText className="w-6 h-6 text-indigo-600" />
                    </div>
                    <p className="text-sm font-medium text-slate-800 break-all">{uploadedFile.name}</p>
                    <button 
                      onClick={() => setUploadedFile(null)}
                      className="mt-3 text-xs text-red-500 hover:text-red-700 font-medium flex items-center gap-1 mx-auto"
                    >
                      <X className="w-3 h-3" /> Remove
                    </button>
                  </div>
                )}
              </div>
            )}
            
            <div className="flex justify-end">
              <button
                onClick={handleCheck}
                disabled={loading || (activeTab === 'text' && !text.trim()) || (activeTab === 'file' && !uploadedFile)}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-medium py-2.5 px-6 rounded-lg transition-colors flex items-center gap-2"
              >
                {loading ? <Spinner /> : <><Search className="w-4 h-4" /> Generate Report</>}
              </button>
            </div>
            
            {error && (
              <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-md border border-red-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                {error}
              </div>
            )}
          </div>
        </div>
      )}

      {/* REPORT SECTION */}
      {result && (
        <div className="animate-fade-in">
          <div className="flex justify-end mb-4 gap-3">
            {isHistoryView && (
               <span className="px-3 py-2 bg-slate-100 text-slate-500 text-sm rounded-lg flex items-center gap-2">
                 <CheckCircle className="w-4 h-4" /> Saved
               </span>
            )}
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg shadow-md transition-colors"
            >
              <Download className="w-4 h-4" /> Download PDF Report
            </button>
          </div>

          {/* PDF CONTENT CONTAINER */}
          <div id="report-content" className="bg-white text-slate-900 p-8 md:p-12 shadow-xl border border-slate-200 mx-auto max-w-[210mm] min-h-[297mm] relative">
            
            {/* REPORT HEADER */}
            <div className="flex items-center justify-between border-b-2 border-indigo-600 pb-6 mb-8">
              <div className="flex items-center gap-3">
                 <div className="bg-indigo-600 p-2 rounded-lg">
                    <Book className="w-6 h-6 text-white" />
                 </div>
                 <div>
                   <h1 className="text-2xl font-bold text-indigo-900">AI PaperQuest</h1>
                   <p className="text-xs text-slate-500 uppercase tracking-widest">Similarity Report</p>
                 </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-500">Generated by PaperQuest Engine</p>
                <p className="text-xs text-slate-400">{initialData ? new Date(initialData.date).toLocaleDateString() : new Date().toLocaleDateString()}</p>
              </div>
            </div>

            {/* SUBMISSION INFO GRID */}
            <div className="mb-8">
              <h3 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-4 border-l-4 border-indigo-300 pl-3">Submission Information</h3>
              <div className="grid grid-cols-2 gap-y-3 gap-x-8 text-sm">
                <div className="flex justify-between border-b border-slate-100 pb-1">
                  <span className="text-slate-500 font-medium">Author Name</span>
                  <span className="font-semibold text-slate-800">{user.name}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1">
                   <span className="text-slate-500 font-medium">Submission ID</span>
                   <span className="font-semibold text-slate-800">
                     {initialData ? initialData.id.substring(0, 8).toUpperCase() : Math.floor(Math.random() * 10000000)}
                   </span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1">
                   <span className="text-slate-500 font-medium">Title</span>
                   <span className="font-semibold text-slate-800 truncate max-w-[200px]">
                      {initialData ? initialData.title : (uploadedFile ? uploadedFile.name : (text.substring(0, 30) + "..."))}
                   </span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1">
                   <span className="text-slate-500 font-medium">Submission Date</span>
                   <span className="font-semibold text-slate-800">
                     {initialData ? new Date(initialData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]}
                   </span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1">
                   <span className="text-slate-500 font-medium">Total Words</span>
                   <span className="font-semibold text-slate-800">{result.wordCount}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1">
                   <span className="text-slate-500 font-medium">Document Type</span>
                   <span className="font-semibold text-slate-800">Article</span>
                </div>
              </div>
            </div>

            {/* SCORE DASHBOARD */}
            <div className="mb-10 bg-slate-50 rounded-xl border border-slate-200 p-6">
               <h3 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-6 border-l-4 border-indigo-300 pl-3">Result Information</h3>
               
               <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                 
                 {/* SIMILARITY SCORE */}
                 <div className="text-center flex-1">
                    <div className={`text-6xl font-bold ${getGradeColor(result.grade)} mb-2`}>
                       {result.similarityScore}%
                    </div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Similarity Score</p>
                 </div>

                 {/* MATCHED SOURCES COUNT */}
                 <div className="text-center flex-1 border-l border-r border-slate-200 px-4">
                    <div className="text-4xl font-bold text-slate-700 mb-2">
                      {result.matchedSourcesCount}
                    </div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Matched Sources</p>
                 </div>

                 {/* GRADE */}
                 <div className="text-center flex-1">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full text-3xl font-bold border-4 mb-2 ${getGradeBg(result.grade)} ${getGradeColor(result.grade)}`}>
                      {result.grade}
                    </div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Grade</p>
                 </div>
               </div>

               {/* CHARTS / BREAKDOWN */}
               <div className="mt-8 pt-8 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="flex items-center justify-center">
                     {/* Simple CSS Pie Chart Representation */}
                     <div className="relative w-32 h-32 rounded-full" style={{
                        background: `conic-gradient(
                          #3b82f6 0% ${result.breakdown.internet}%, 
                          #f59e0b ${result.breakdown.internet}% ${result.breakdown.internet + result.breakdown.publications}%, 
                          #ef4444 ${result.breakdown.internet + result.breakdown.publications}% 100%
                        )`
                     }}>
                       <div className="absolute inset-0 m-6 bg-slate-50 rounded-full"></div>
                     </div>
                  </div>
                  
                  <div className="flex flex-col justify-center gap-3 text-sm">
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                           <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                           <span className="font-medium text-slate-700">Internet Source</span>
                        </div>
                        <span className="font-bold text-slate-900">{result.breakdown.internet}%</span>
                     </div>
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                           <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                           <span className="font-medium text-slate-700">Publications</span>
                        </div>
                        <span className="font-bold text-slate-900">{result.breakdown.publications}%</span>
                     </div>
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                           <div className="w-3 h-3 rounded-full bg-red-500"></div>
                           <span className="font-medium text-slate-700">Student Papers</span>
                        </div>
                        <span className="font-bold text-slate-900">{result.breakdown.studentPapers}%</span>
                     </div>
                  </div>
               </div>
            </div>

            {/* MATCHED SOURCES TABLE */}
            <div className="mb-8">
               <h3 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-4 border-l-4 border-indigo-300 pl-3">Matched Sources</h3>
               {result.sources.length > 0 ? (
                 <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-slate-600 font-semibold uppercase text-xs">
                       <tr>
                          <th className="p-3 rounded-tl-lg">#</th>
                          <th className="p-3">Source Domain / Title</th>
                          <th className="p-3 text-right">% Match</th>
                          <th className="p-3 rounded-tr-lg text-right">Type</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {result.sources.map((source, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                             <td className="p-3 text-slate-500 w-10">{idx + 1}</td>
                             <td className="p-3">
                                <div className="font-medium text-slate-800">{source.title}</div>
                                <a href={source.uri} target="_blank" className="text-xs text-indigo-600 hover:underline truncate max-w-[300px] block">{source.uri}</a>
                             </td>
                             <td className="p-3 text-right font-bold text-slate-700">
                                {/* Simulate varying low percentages for individual sources */}
                                {Math.max(1, Math.floor(Math.random() * 5))}%
                             </td>
                             <td className="p-3 text-right text-slate-500">
                                Internet
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
               ) : (
                 <div className="p-6 bg-green-50 border border-green-100 rounded-lg text-center">
                    <p className="text-green-800 font-medium">No significant matches found.</p>
                 </div>
               )}
            </div>

            {/* EXCLUDED INFO */}
             <div className="mb-8">
              <h3 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-4 border-l-4 border-indigo-300 pl-3">Exclude Information</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                 <div className="flex justify-between p-2 bg-slate-50 rounded">
                    <span className="text-slate-600">Quotes</span>
                    <span className="font-semibold text-slate-900">Excluded</span>
                 </div>
                 <div className="flex justify-between p-2 bg-slate-50 rounded">
                    <span className="text-slate-600">Bibliography</span>
                    <span className="font-semibold text-slate-900">Excluded</span>
                 </div>
                 <div className="flex justify-between p-2 bg-slate-50 rounded">
                    <span className="text-slate-600">Small Matches (&lt; 15 words)</span>
                    <span className="font-semibold text-slate-900">Excluded</span>
                 </div>
              </div>
            </div>
            
            {/* FOOTER QR MOCKUP */}
            <div className="mt-12 pt-6 border-t border-slate-200 flex items-end justify-between">
               <p className="text-xs text-slate-400">
                 Report generated by AI PaperQuest. <br/>
                 This report is for informational purposes only.
               </p>
               <div className="w-20 h-20 bg-white border border-slate-200 p-1">
                  {/* Simple CSS Grid for QR effect */}
                  <div className="w-full h-full grid grid-cols-5 grid-rows-5 gap-0.5 bg-slate-100">
                     {[...Array(25)].map((_, i) => (
                        <div key={i} className={`${Math.random() > 0.5 ? 'bg-slate-800' : 'bg-transparent'}`}></div>
                     ))}
                  </div>
               </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};