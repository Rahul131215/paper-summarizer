import React from 'react';
import { LayoutDashboard, FileText, ShieldCheck, LogOut, X, Book, User as UserIcon } from 'lucide-react';
import { AppMode, User } from '../types';

interface SidebarProps {
  user: User;
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  onLogout: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  user, 
  currentMode, 
  onModeChange, 
  onLogout, 
  isOpen, 
  onClose 
}) => {
  const navItems = [
    { 
      mode: AppMode.DASHBOARD, 
      label: 'Dashboard', 
      icon: LayoutDashboard 
    },
    { 
      mode: AppMode.SUMMARIZER, 
      label: 'Summarizer', 
      icon: FileText 
    },
    { 
      mode: AppMode.PLAGIARISM_CHECKER, 
      label: 'Plagiarism Checker', 
      icon: ShieldCheck 
    }
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`
          fixed top-0 left-0 z-50 h-full w-72 bg-slate-900 text-white transition-transform duration-300 ease-in-out shadow-2xl
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Logo Area */}
          <div className="h-20 flex items-center px-6 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-primary-500 to-indigo-600 p-2 rounded-xl shadow-lg shadow-primary-900/20">
                <Book className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">PaperQuest</h1>
                <p className="text-xs text-slate-400">AI Research Assistant</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="ml-auto lg:hidden text-slate-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 px-4 py-8 space-y-2 overflow-y-auto">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 mb-4">
              Menu
            </div>
            
            {navItems.map((item) => {
              const isActive = currentMode === item.mode;
              const Icon = item.icon;
              
              return (
                <button
                  key={item.mode}
                  onClick={() => {
                    onModeChange(item.mode);
                    onClose();
                  }}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-200 group
                    ${isActive 
                      ? 'bg-primary-600 text-white shadow-lg shadow-primary-900/50' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }
                  `}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'}`} />
                  {item.label}
                  {isActive && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* User Profile & Logout */}
          <div className="p-4 border-t border-slate-800 bg-slate-900/50">
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 flex items-center justify-center text-white font-bold shadow-lg">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div className="overflow-hidden">
                  <p className="text-sm font-semibold text-white truncate">{user.name}</p>
                  <p className="text-xs text-slate-400 truncate">{user.email}</p>
                </div>
              </div>
              
              <button 
                onClick={onLogout}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-red-500/10 hover:text-red-400 text-slate-300 text-xs font-medium rounded-lg transition-colors border border-slate-700 hover:border-red-500/30"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};