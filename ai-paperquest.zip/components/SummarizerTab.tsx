import React, { useState, useEffect } from 'react';
import { FileText, Upload, X, CheckCircle, BookOpen, Target, FlaskConical, Lightbulb, Download, Brain, ChevronLeft } from 'lucide-react';
import { summarizePaper } from '../services/geminiService';
import { saveHistoryItem } from '../services/storageService';
import { UploadedFile, SummaryResult, HistoryItem } from '../types';
import { Spinner } from './Spinner';

interface SummarizerTabProps {
  initialData?: HistoryItem | null;
  onBack?: () => void;
}

export const SummarizerTab: React.FC<SummarizerTabProps> = ({ initialData, onBack }) => {
  const [activeTab, setActiveTab] = useState<'text' | 'file'>('text');
  const [inputText, setInputText] = useState('');
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SummaryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isHistoryView, setIsHistoryView] = useState(false);

  useEffect(() => {
    if (initialData && initialData.type === 'SUMMARY') {
      setResult(initialData.data as SummaryResult);
      setIsHistoryView(true);
      // Optional: set title or file name context if needed
    } else {
      setResult(null);
      setIsHistoryView(false);
      setInputText('');
      setUploadedFile(null);
    }
  }, [initialData]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf' && file.type !== 'text/plain') {
      setError("Please upload a PDF or Text file.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      const base64Data = base64String.split(',')[1];
      
      setUploadedFile({
        name: file.name,
        type: file.type,
        data: base64Data
      });
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSummarize = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    setIsHistoryView(false);

    try {
      let summaryData: SummaryResult;
      let title = "Text Summary";
      
      if (activeTab === 'file' && uploadedFile) {
         title = uploadedFile.name;
         if (uploadedFile.type === 'application/pdf') {
             summaryData = await summarizePaper(uploadedFile.data, true);
         } else {
             summaryData = await summarizePaper(uploadedFile.data, true);
         }
      } else if (activeTab === 'text' && inputText.trim()) {
        title = inputText.substring(0, 30) + "...";
        summaryData = await summarizePaper(inputText, false);
      } else {
        throw new Error("Please provide text or a file to summarize.");
      }

      setResult(summaryData);
      
      // Auto Save to History
      saveHistoryItem('SUMMARY', summaryData, title, activeTab === 'file' ? uploadedFile?.name : undefined);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to summarize. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = () => {
    const element = document.getElementById('summary-report-content');
    if (!element) return;

    const opt = {
      margin: 0.5,
      filename: `Summary_Report_${new Date().getTime()}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // @ts-ignore
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert("PDF generator not loaded. Please refresh.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      
      {/* Back Button for History View */}
      {isHistoryView && onBack && (
        <button onClick={onBack} className="mb-6 flex items-center gap-2 text-slate-500 hover:text-slate-800 transition-colors">
          <ChevronLeft className="w-4 h-4" /> Back to Dashboard
        </button>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Section - Hide if viewing history to focus on content */}
        {!isHistoryView && (
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary-600" />
                Input Source
              </h2>
              
              <div className="flex gap-2 mb-4 p-1 bg-slate-100 rounded-lg w-full">
                <button
                  onClick={() => setActiveTab('text')}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-all ${
                    activeTab === 'text' 
                      ? 'bg-white text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Paste Text
                </button>
                <button
                  onClick={() => setActiveTab('file')}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-all ${
                    activeTab === 'file' 
                      ? 'bg-white text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Upload PDF
                </button>
              </div>

              {activeTab === 'text' ? (
                <textarea
                  className="w-full h-64 p-4 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none font-serif text-sm leading-relaxed"
                  placeholder="Paste the abstract or full text of the research paper here..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                />
              ) : (
                <div className="h-64 border-2 border-dashed border-slate-300 rounded-lg flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors relative">
                  {!uploadedFile ? (
                    <>
                      <Upload className="w-10 h-10 text-slate-400 mb-3" />
                      <p className="text-sm text-slate-600 font-medium">Click to upload PDF</p>
                      <p className="text-xs text-slate-400 mt-1">Max 10MB</p>
                      <input 
                        type="file" 
                        accept="application/pdf"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={handleFileUpload}
                      />
                    </>
                  ) : (
                    <div className="text-center p-4">
                      <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <FileText className="w-6 h-6 text-red-500" />
                      </div>
                      <p className="text-sm font-medium text-slate-800 break-all">{uploadedFile.name}</p>
                      <button 
                        onClick={() => setUploadedFile(null)}
                        className="mt-3 text-xs text-red-500 hover:text-red-700 font-medium flex items-center gap-1 mx-auto"
                      >
                        <X className="w-3 h-3" /> Remove
                      </button>
                    </div>
                  )}
                </div>
              )}

              {error && (
                <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-md border border-red-100">
                  {error}
                </div>
              )}

              <button
                onClick={handleSummarize}
                disabled={loading || (activeTab === 'text' && !inputText) || (activeTab === 'file' && !uploadedFile)}
                className="w-full mt-6 bg-primary-600 hover:bg-primary-700 disabled:bg-slate-300 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {loading ? <Spinner /> : <><Lightbulb className="w-5 h-5" /> Generate Summary</>}
              </button>
            </div>
          </div>
        )}

        {/* Output Section - Expand to full width if viewing history */}
        <div className={isHistoryView ? "col-span-12" : "lg:col-span-8"}>
          {result ? (
            <div className="animate-fade-in">
              <div className="flex justify-end mb-4 gap-3">
                 {isHistoryView && (
                   <span className="px-3 py-2 bg-slate-100 text-slate-500 text-sm rounded-lg flex items-center gap-2">
                     <CheckCircle className="w-4 h-4" /> Saved
                   </span>
                 )}
                <button
                  onClick={handleDownloadPDF}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg shadow-md transition-colors"
                >
                  <Download className="w-4 h-4" /> Download PDF
                </button>
              </div>

              {/* Document Layout for Report & PDF */}
              <div id="summary-report-content" className="bg-white text-slate-900 p-8 md:p-12 shadow-xl border border-slate-200 mx-auto min-h-[297mm] relative max-w-4xl">
                
                {/* Header */}
                <div className="flex items-center justify-between border-b-2 border-primary-600 pb-6 mb-8">
                  <div className="flex items-center gap-3">
                     <div className="bg-primary-600 p-2 rounded-lg">
                        <Brain className="w-6 h-6 text-white" />
                     </div>
                     <div>
                       <h1 className="text-2xl font-bold text-primary-900">AI PaperQuest</h1>
                       <p className="text-xs text-slate-500 uppercase tracking-widest">Executive Summary</p>
                     </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-500">
                      Generated on {initialData ? new Date(initialData.date).toLocaleDateString() : new Date().toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="space-y-8 font-serif">
                  {/* Abstract Section */}
                  <section>
                    <h3 className="font-sans text-lg font-bold text-slate-900 mb-3 flex items-center gap-2 uppercase tracking-wider border-l-4 border-primary-400 pl-3">
                      Abstract
                    </h3>
                    <div className="text-slate-700 text-base leading-relaxed bg-slate-50 p-6 rounded-r-lg border-l-4 border-slate-200 text-justify">
                      {result.abstract}
                    </div>
                  </section>

                  {/* Key Findings Section */}
                  <section>
                    <h3 className="font-sans text-lg font-bold text-slate-900 mb-4 flex items-center gap-2 uppercase tracking-wider border-l-4 border-emerald-500 pl-3">
                       Key Findings
                    </h3>
                    <div className="grid gap-3">
                      {result.keyFindings.map((point, idx) => (
                        <div key={idx} className="flex gap-4 items-start group">
                          <div className="mt-1.5 w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0 group-hover:scale-125 transition-transform"></div>
                          <p className="text-slate-700 text-base leading-relaxed">{point}</p>
                        </div>
                      ))}
                    </div>
                  </section>

                  {/* Methodology Section */}
                  <section>
                    <h3 className="font-sans text-lg font-bold text-slate-900 mb-3 flex items-center gap-2 uppercase tracking-wider border-l-4 border-violet-500 pl-3">
                       Methodology
                    </h3>
                    <p className="text-slate-700 text-base leading-relaxed text-justify">
                      {result.methodology}
                    </p>
                  </section>

                  {/* Conclusion Section */}
                  <section className="bg-slate-900 text-slate-50 p-8 rounded-xl shadow-sm mt-8">
                    <h3 className="font-sans text-lg font-bold text-white mb-3 uppercase tracking-wider">
                      Conclusion
                    </h3>
                    <p className="text-slate-300 text-base leading-relaxed italic">
                      "{result.conclusion}"
                    </p>
                  </section>
                </div>

                {/* Footer */}
                <div className="mt-16 pt-6 border-t border-slate-200 flex items-end justify-between font-sans">
                   <p className="text-xs text-slate-400">
                     Summarized by AI PaperQuest Intelligence Engine. <br/>
                     Verify critical information with the original source text.
                   </p>
                   <div className="text-right">
                      <p className="text-xs font-bold text-slate-300 uppercase">PaperQuest</p>
                   </div>
                </div>
              </div>
            </div>
          ) : (
             !isHistoryView && (
              <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                <BookOpen className="w-16 h-16 mb-4 opacity-20" />
                <p className="text-lg font-medium">Ready to analyze</p>
                <p className="text-sm">Upload a paper or paste text to begin</p>
              </div>
             )
          )}
        </div>
      </div>
    </div>
  );
};