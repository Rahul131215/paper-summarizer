import React, { useEffect, useState } from 'react';
import { FileText, ShieldCheck, Clock, Trash2, ArrowRight, Plus, Search, LayoutDashboard } from 'lucide-react';
import { HistoryItem, User, AppMode } from '../types';
import { getHistory, deleteHistoryItem, getStats } from '../services/storageService';

interface DashboardProps {
  user: User;
  onNavigate: (mode: AppMode, item?: HistoryItem) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onNavigate }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [stats, setStats] = useState({ totalDocs: 0, summariesCount: 0, reportsCount: 0, lastActivity: 'N/A' });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setHistory(getHistory());
    setStats(getStats());
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this item?')) {
      const updated = deleteHistoryItem(id);
      setHistory(updated);
      setStats(getStats());
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-1">Welcome back, {user.name}. Here is your research overview.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate(AppMode.SUMMARIZER)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 font-medium rounded-lg hover:bg-slate-50 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" /> New Summary
          </button>
          <button 
             onClick={() => onNavigate(AppMode.PLAGIARISM_CHECKER)}
             className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-md shadow-indigo-200"
          >
            <Plus className="w-4 h-4" /> New Check
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
              <LayoutDashboard className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs font-bold text-slate-400 uppercase">Total</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900">{stats.totalDocs}</h3>
          <p className="text-sm text-slate-500">Documents Processed</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-indigo-50 rounded-lg group-hover:bg-indigo-100 transition-colors">
              <FileText className="w-6 h-6 text-indigo-600" />
            </div>
            <span className="text-xs font-bold text-slate-400 uppercase">Summaries</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900">{stats.summariesCount}</h3>
          <p className="text-sm text-slate-500">Generated Summaries</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-violet-50 rounded-lg group-hover:bg-violet-100 transition-colors">
              <ShieldCheck className="w-6 h-6 text-violet-600" />
            </div>
            <span className="text-xs font-bold text-slate-400 uppercase">Reports</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900">{stats.reportsCount}</h3>
          <p className="text-sm text-slate-500">Plagiarism Checks</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow group">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-orange-50 rounded-lg group-hover:bg-orange-100 transition-colors">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-xs font-bold text-slate-400 uppercase">Activity</span>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 whitespace-nowrap text-ellipsis overflow-hidden">{stats.lastActivity}</h3>
          <p className="text-sm text-slate-500">Last Action Date</p>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h2 className="text-lg font-bold text-slate-900">Recent Work History</h2>
          <div className="relative hidden sm:block">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search history..." 
              className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-100 outline-none w-64"
            />
          </div>
        </div>

        {history.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium">
                <tr>
                  <th className="px-6 py-4">Document Name</th>
                  <th className="px-6 py-4">Type</th>
                  <th className="px-6 py-4">Date Generated</th>
                  <th className="px-6 py-4">Preview / Result</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {history.map((item) => (
                  <tr 
                    key={item.id} 
                    className="hover:bg-slate-50 transition-colors cursor-pointer group"
                    onClick={() => onNavigate(
                      item.type === 'SUMMARY' ? AppMode.SUMMARIZER : AppMode.PLAGIARISM_CHECKER, 
                      item
                    )}
                  >
                    <td className="px-6 py-4 font-medium text-slate-900">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${item.type === 'SUMMARY' ? 'bg-blue-100 text-blue-600' : 'bg-violet-100 text-violet-600'}`}>
                           {item.type === 'SUMMARY' ? <FileText className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
                        </div>
                        {item.title}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        item.type === 'SUMMARY' 
                          ? 'bg-blue-50 text-blue-700' 
                          : 'bg-violet-50 text-violet-700'
                      }`}>
                        {item.type === 'SUMMARY' ? 'Summary' : 'Similarity Check'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-500">
                      {new Date(item.date).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-slate-500 max-w-xs truncate">
                      {item.previewText}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-indigo-600 font-medium text-xs flex items-center gap-1 mr-2">
                          View <ArrowRight className="w-3 h-3" />
                        </span>
                        <button 
                          onClick={(e) => handleDelete(e, item.id)}
                          className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mb-4">
              <Clock className="w-8 h-8 text-slate-300" />
            </div>
            <h3 className="text-lg font-medium text-slate-900">No history yet</h3>
            <p className="text-slate-500 mt-2 max-w-sm mx-auto">
              Start by uploading a paper to summarize or checking a document for plagiarism. Your results will appear here automatically.
            </p>
            <div className="mt-6 flex justify-center gap-4">
               <button 
                 onClick={() => onNavigate(AppMode.SUMMARIZER)}
                 className="text-indigo-600 font-medium hover:text-indigo-800 text-sm"
               >
                 Create Summary &rarr;
               </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};