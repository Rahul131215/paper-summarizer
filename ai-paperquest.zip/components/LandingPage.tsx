import React, { useState, useEffect } from 'react';
import { BookOpen, ShieldCheck, Zap, BrainCircuit, Users, ArrowRight, CheckCircle, Star, Search, FileText, LayoutDashboard } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white font-sans selection:bg-primary-200 selection:text-primary-900 overflow-x-hidden">
      
      {/* Navbar */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'glass-nav shadow-sm py-3' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary-600 p-2 rounded-xl shadow-lg shadow-primary-600/20">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <span className={`text-xl font-bold tracking-tight ${scrolled ? 'text-slate-900' : 'text-slate-900'}`}>PaperQuest</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="hidden sm:block text-sm font-medium text-slate-600 hover:text-primary-600 transition-colors">Features</button>
            <button className="hidden sm:block text-sm font-medium text-slate-600 hover:text-primary-600 transition-colors">Pricing</button>
            <button 
              onClick={onGetStarted}
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-full transition-all transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              Sign In
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative pt-32 pb-20 sm:pt-40 sm:pb-24 lg:pb-32 overflow-hidden">
        {/* Animated Background Blobs */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full z-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
          <div className="absolute top-0 right-1/4 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-1/3 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary-100/50 rounded-full blur-3xl -z-10"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 border border-primary-100 text-primary-700 text-xs font-bold uppercase tracking-wide mb-8 animate-fade-in-up">
            <Zap className="w-3 h-3" />
            <span>New: Gemini 2.5 Flash Engine Integration</span>
          </div>
          
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold text-slate-900 tracking-tight mb-8 leading-[1.1] animate-fade-in-up delay-100">
            Research Intelligence <br className="hidden md:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 via-violet-600 to-indigo-600">
              Reimagined with AI
            </span>
          </h1>
          
          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-slate-600 mb-10 leading-relaxed animate-fade-in-up delay-200">
            The ultimate companion for academics. Instantly summarize complex papers, extract key methodologies, and verify originality with deep web grounding.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up delay-300">
            <button 
              onClick={onGetStarted}
              className="w-full sm:w-auto px-8 py-4 bg-primary-600 hover:bg-primary-700 text-white text-lg font-bold rounded-2xl transition-all transform hover:scale-105 hover:-translate-y-1 shadow-xl shadow-primary-500/30 flex items-center justify-center gap-2"
            >
              Start Analyzing Free
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-slate-50 text-slate-700 text-lg font-bold rounded-2xl transition-all border border-slate-200 shadow-sm hover:shadow-md flex items-center justify-center gap-2">
               Watch Demo
            </button>
          </div>

          {/* Floating Dashboard Mockup */}
          <div className="mt-20 relative mx-auto max-w-5xl animate-fade-in-up delay-500 perspective-1000">
            {/* Decorative Elements behind mockup */}
            <div className="absolute -top-12 -right-12 w-24 h-24 bg-yellow-400 rounded-2xl rotate-12 animate-float-delayed z-0 opacity-80 blur-sm"></div>
            <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-primary-500 rounded-full animate-float z-0 opacity-80 blur-sm"></div>

            <div className="relative bg-slate-900 rounded-2xl p-2 shadow-2xl border border-slate-700/50 backdrop-blur-sm rotate-x-2 hover:rotate-0 transition-transform duration-700 ease-out">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-white/10 to-transparent rounded-2xl pointer-events-none"></div>
              {/* Header of Mockup */}
              <div className="bg-slate-800 rounded-t-xl h-10 flex items-center px-4 gap-2 border-b border-slate-700">
                 <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                 </div>
                 <div className="ml-4 bg-slate-700 h-5 w-64 rounded-md"></div>
              </div>
              {/* Body of Mockup */}
              <div className="bg-slate-50 rounded-b-xl p-6 grid grid-cols-12 gap-6 h-[400px] overflow-hidden">
                 {/* Sidebar Mockup */}
                 <div className="col-span-3 bg-white rounded-lg shadow-sm p-4 flex flex-col gap-3 border border-slate-100">
                    <div className="h-8 bg-primary-100 rounded w-3/4 mb-4"></div>
                    <div className="h-4 bg-slate-100 rounded w-full"></div>
                    <div className="h-4 bg-slate-100 rounded w-5/6"></div>
                    <div className="h-4 bg-slate-100 rounded w-4/5"></div>
                 </div>
                 {/* Main Content Mockup */}
                 <div className="col-span-9 flex flex-col gap-4">
                    <div className="flex gap-4">
                       <div className="flex-1 bg-white h-24 rounded-lg shadow-sm border border-slate-100 p-4">
                          <div className="w-8 h-8 bg-blue-100 rounded-md mb-2"></div>
                          <div className="w-1/2 h-4 bg-slate-100 rounded"></div>
                       </div>
                       <div className="flex-1 bg-white h-24 rounded-lg shadow-sm border border-slate-100 p-4">
                          <div className="w-8 h-8 bg-green-100 rounded-md mb-2"></div>
                          <div className="w-1/2 h-4 bg-slate-100 rounded"></div>
                       </div>
                       <div className="flex-1 bg-white h-24 rounded-lg shadow-sm border border-slate-100 p-4">
                          <div className="w-8 h-8 bg-purple-100 rounded-md mb-2"></div>
                          <div className="w-1/2 h-4 bg-slate-100 rounded"></div>
                       </div>
                    </div>
                    <div className="flex-1 bg-white rounded-lg shadow-sm border border-slate-100 p-6 flex gap-6">
                       <div className="flex-1 space-y-3">
                          <div className="w-3/4 h-6 bg-slate-200 rounded mb-4"></div>
                          <div className="w-full h-3 bg-slate-100 rounded"></div>
                          <div className="w-full h-3 bg-slate-100 rounded"></div>
                          <div className="w-5/6 h-3 bg-slate-100 rounded"></div>
                          <div className="w-full h-3 bg-slate-100 rounded"></div>
                       </div>
                       <div className="w-1/3 bg-slate-50 rounded-lg border border-slate-100"></div>
                    </div>
                 </div>
              </div>
            </div>
          </div>

          {/* Social Proof */}
          <div className="mt-16 pt-10 border-t border-slate-200/60">
            <p className="text-sm font-medium text-slate-500 mb-6">TRUSTED BY RESEARCHERS FROM</p>
            <div className="flex flex-wrap justify-center gap-8 sm:gap-16 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
               {/* Placeholder Logos */}
               <div className="flex items-center gap-2 font-bold text-xl text-slate-700"><div className="w-6 h-6 bg-slate-800 rounded-full"></div> Stanford</div>
               <div className="flex items-center gap-2 font-bold text-xl text-slate-700"><div className="w-6 h-6 bg-slate-800 rounded-full"></div> MIT</div>
               <div className="flex items-center gap-2 font-bold text-xl text-slate-700"><div className="w-6 h-6 bg-slate-800 rounded-full"></div> Oxford</div>
               <div className="flex items-center gap-2 font-bold text-xl text-slate-700"><div className="w-6 h-6 bg-slate-800 rounded-full"></div> Berkeley</div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-24 bg-slate-50 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-white/50 to-transparent pointer-events-none"></div>
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center max-w-3xl mx-auto mb-20">
               <h2 className="text-primary-600 font-bold tracking-wide uppercase text-sm mb-3">Powerful Features</h2>
               <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Everything you need to accelerate your research workflow.</h3>
               <p className="text-lg text-slate-600">Don't let information overload slow you down. Use AI to synthesize, verify, and organize academic literature instantly.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
               {/* Feature 1 */}
               <div className="bg-white p-8 rounded-3xl shadow-lg shadow-slate-200/50 border border-slate-100 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300 group">
                  <div className="w-14 h-14 bg-blue-500 rounded-2xl flex items-center justify-center mb-6 text-white shadow-lg shadow-blue-500/30 group-hover:scale-110 transition-transform">
                     <BookOpen className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-3">Smart Summarization</h4>
                  <p className="text-slate-600 leading-relaxed">
                     Turn 50-page PDFs into concise executive summaries. Extract abstracts, key findings, and methodologies automatically.
                  </p>
                  <div className="mt-6 pt-6 border-t border-slate-100 flex items-center gap-2 text-sm font-medium text-blue-600">
                     <CheckCircle className="w-4 h-4" /> Extracts Citations
                  </div>
               </div>

               {/* Feature 2 */}
               <div className="bg-white p-8 rounded-3xl shadow-lg shadow-slate-200/50 border border-slate-100 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300 group relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-gradient-to-bl from-primary-50 to-transparent w-32 h-32 rounded-bl-full -mr-8 -mt-8"></div>
                  <div className="w-14 h-14 bg-violet-600 rounded-2xl flex items-center justify-center mb-6 text-white shadow-lg shadow-violet-600/30 group-hover:scale-110 transition-transform relative z-10">
                     <ShieldCheck className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-3">Plagiarism Detection</h4>
                  <p className="text-slate-600 leading-relaxed">
                     Cross-reference your text with billions of web pages. Get a detailed similarity score and source breakdown report.
                  </p>
                  <div className="mt-6 pt-6 border-t border-slate-100 flex items-center gap-2 text-sm font-medium text-violet-600">
                     <CheckCircle className="w-4 h-4" /> Google Search Grounding
                  </div>
               </div>

               {/* Feature 3 */}
               <div className="bg-white p-8 rounded-3xl shadow-lg shadow-slate-200/50 border border-slate-100 hover:-translate-y-2 hover:shadow-2xl transition-all duration-300 group">
                  <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center mb-6 text-white shadow-lg shadow-indigo-600/30 group-hover:scale-110 transition-transform">
                     <LayoutDashboard className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 mb-3">History & Analytics</h4>
                  <p className="text-slate-600 leading-relaxed">
                     Keep track of all your research in one dashboard. View statistics on your reading habits and revisit past summaries.
                  </p>
                  <div className="mt-6 pt-6 border-t border-slate-100 flex items-center gap-2 text-sm font-medium text-indigo-600">
                     <CheckCircle className="w-4 h-4" /> Auto-save Progress
                  </div>
               </div>
            </div>
         </div>
      </div>

      {/* How it works steps */}
      <div className="py-24 bg-white">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
               <h2 className="text-3xl font-bold text-slate-900">How PaperQuest Works</h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-12 relative">
               {/* Connecting Line */}
               <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-0.5 bg-gradient-to-r from-transparent via-slate-200 to-transparent z-0"></div>

               <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="w-24 h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center shadow-sm mb-6 text-2xl font-bold text-slate-300 group hover:border-primary-200 hover:text-primary-600 transition-colors">
                     <span className="text-slate-900 group-hover:text-primary-600">1</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Upload</h3>
                  <p className="text-slate-500">Drag & drop your PDF research paper or paste text directly.</p>
               </div>

               <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="w-24 h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center shadow-sm mb-6 text-2xl font-bold text-slate-300 group hover:border-primary-200 hover:text-primary-600 transition-colors">
                     <span className="text-slate-900 group-hover:text-primary-600">2</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Analyze</h3>
                  <p className="text-slate-500">Our AI engine scans, summarizes, and checks for originality in seconds.</p>
               </div>

               <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="w-24 h-24 bg-white rounded-full border-4 border-slate-100 flex items-center justify-center shadow-sm mb-6 text-2xl font-bold text-slate-300 group hover:border-primary-200 hover:text-primary-600 transition-colors">
                     <span className="text-slate-900 group-hover:text-primary-600">3</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Download</h3>
                  <p className="text-slate-500">Get your structured report or executive summary as a PDF.</p>
               </div>
            </div>
         </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 relative overflow-hidden">
         <div className="absolute inset-0 bg-slate-900 z-0">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            <div className="absolute bottom-0 right-0 w-1/2 h-full bg-gradient-to-t from-primary-900 to-transparent opacity-50"></div>
         </div>
         
         <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">Ready to upgrade your research?</h2>
            <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">Join thousands of students and researchers using AI PaperQuest to write better papers, faster.</p>
            <button 
              onClick={onGetStarted}
              className="px-10 py-5 bg-white text-slate-900 text-lg font-bold rounded-2xl shadow-2xl hover:bg-primary-50 transition-all transform hover:scale-105 flex items-center gap-2 mx-auto"
            >
              Get Started Now - It's Free
              <ArrowRight className="w-5 h-5" />
            </button>
            <p className="mt-6 text-sm text-slate-500">No credit card required. Free tier available.</p>
         </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-primary-600 p-1.5 rounded-lg">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-slate-900">PaperQuest</span>
              </div>
              <p className="text-sm text-slate-500">
                Empowering the next generation of researchers with ethical, powerful AI tools.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-primary-600">Summarizer</a></li>
                <li><a href="#" className="hover:text-primary-600">Plagiarism Checker</a></li>
                <li><a href="#" className="hover:text-primary-600">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-primary-600">Blog</a></li>
                <li><a href="#" className="hover:text-primary-600">Documentation</a></li>
                <li><a href="#" className="hover:text-primary-600">Community</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-primary-600">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary-600">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-400">© {new Date().getFullYear()} AI PaperQuest. All rights reserved.</p>
            <div className="flex gap-4">
              {/* Social icons placeholders */}
              <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-primary-100 hover:text-primary-600 transition-colors cursor-pointer">
                 <span className="font-bold text-xs">Tw</span>
              </div>
              <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-primary-100 hover:text-primary-600 transition-colors cursor-pointer">
                 <span className="font-bold text-xs">Li</span>
              </div>
              <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-primary-100 hover:text-primary-600 transition-colors cursor-pointer">
                 <span className="font-bold text-xs">Gh</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};