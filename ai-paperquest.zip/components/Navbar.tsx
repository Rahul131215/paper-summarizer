import React from 'react';
import { Book, ShieldCheck, FileText, LogOut, User as UserIcon, LayoutDashboard } from 'lucide-react';
import { AppMode, User } from '../types';

interface NavbarProps {
  user: User;
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ user, currentMode, onModeChange, onLogout }) => {
  return (
    <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          onClick={() => onModeChange(AppMode.DASHBOARD)}
        >
          <div className="bg-primary-600 p-2 rounded-lg shadow-lg shadow-primary-600/20">
            <Book className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-700 hidden sm:block">
            PaperQuest
          </span>
        </div>
        
        {/* Navigation Pills */}
        <div className="hidden md:flex items-center gap-1 bg-slate-100/80 p-1.5 rounded-xl border border-slate-200">
           <button
            onClick={() => onModeChange(AppMode.DASHBOARD)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              currentMode === AppMode.DASHBOARD
                ? 'bg-white text-slate-900 shadow-sm ring-1 ring-black/5'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" /> 
            <span>Dashboard</span>
          </button>
          <div className="w-px h-6 bg-slate-300 mx-1"></div>
          <button
            onClick={() => onModeChange(AppMode.SUMMARIZER)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              currentMode === AppMode.SUMMARIZER
                ? 'bg-white text-primary-700 shadow-sm ring-1 ring-black/5'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
            }`}
          >
            <FileText className="w-4 h-4" /> 
            <span>Summarizer</span>
          </button>
          <button
            onClick={() => onModeChange(AppMode.PLAGIARISM_CHECKER)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              currentMode === AppMode.PLAGIARISM_CHECKER
                ? 'bg-white text-indigo-700 shadow-sm ring-1 ring-black/5'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> 
            <span>Check Plagiarism</span>
          </button>
        </div>

        {/* Mobile view simplified nav (only current title) */}
        <div className="md:hidden font-medium text-slate-800">
          {currentMode === AppMode.DASHBOARD && 'Dashboard'}
          {currentMode === AppMode.SUMMARIZER && 'Summarizer'}
          {currentMode === AppMode.PLAGIARISM_CHECKER && 'Plagiarism'}
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-4 pl-4 border-l border-slate-200 ml-4">
          <div className="hidden lg:block text-right">
            <p className="text-sm font-semibold text-slate-800 leading-none">{user.name}</p>
            <p className="text-xs text-slate-500 mt-1 leading-none">{user.email}</p>
          </div>
          <div className="relative group">
            <button className="w-9 h-9 bg-slate-100 rounded-full flex items-center justify-center border border-slate-200 text-slate-600 overflow-hidden">
               {user.name.charAt(0).toUpperCase()}
            </button>
            
            {/* Dropdown */}
            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-lg shadow-xl border border-slate-100 py-1 hidden group-hover:block animate-fade-in z-50">
              <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
                <p className="text-sm font-medium text-slate-900">{user.name}</p>
                <p className="text-xs text-slate-500 truncate">{user.email}</p>
              </div>
              <div className="md:hidden border-b border-slate-100">
                 <button onClick={() => onModeChange(AppMode.DASHBOARD)} className="w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">Dashboard</button>
                 <button onClick={() => onModeChange(AppMode.SUMMARIZER)} className="w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">Summarizer</button>
                 <button onClick={() => onModeChange(AppMode.PLAGIARISM_CHECKER)} className="w-full text-left px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">Plagiarism Check</button>
              </div>
              <button 
                onClick={onLogout}
                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};