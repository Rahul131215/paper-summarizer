import { GoogleGenAI, Type } from "@google/genai";
import { SummaryResult, PlagiarismResult, GroundingSource } from "../types";

const apiKey = process.env.API_KEY || '';

// Singleton instance handling
let aiInstance: GoogleGenAI | null = null;

const getAiClient = () => {
  if (!apiKey) {
    throw new Error("API Key not found in environment variables.");
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
};

export const summarizePaper = async (
  content: string,
  isBase64Pdf: boolean = false
): Promise<SummaryResult> => {
  const ai = getAiClient();
  
  const model = "gemini-2.5-flash";

  const promptText = `
    You are an expert academic researcher. Analyze the provided research paper content.
    Extract and structure the following information:
    1. A concise Abstract.
    2. A list of Key Findings (bullet points).
    3. A brief explanation of the Methodology used.
    4. A solid Conclusion.
    
    Ensure the tone is academic and objective.
  `;

  const parts = [];
  
  if (isBase64Pdf) {
    parts.push({
      inlineData: {
        mimeType: 'application/pdf',
        data: content
      }
    });
  } else {
    parts.push({ text: content });
  }
  
  parts.push({ text: promptText });

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          abstract: { type: Type.STRING },
          keyFindings: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          methodology: { type: Type.STRING },
          conclusion: { type: Type.STRING }
        },
        required: ["abstract", "keyFindings", "methodology", "conclusion"]
      }
    }
  });

  const resultText = response.text;
  if (!resultText) throw new Error("No response generated");

  return JSON.parse(resultText) as SummaryResult;
};

export const checkPlagiarism = async (
  content: string, 
  isBase64Pdf: boolean = false
): Promise<PlagiarismResult> => {
  const ai = getAiClient();
  const model = "gemini-2.5-flash";

  // Calculate rough word count for the input
  let wordCount = 0;
  if (!isBase64Pdf) {
    wordCount = content.split(/\s+/).length;
  } else {
    // For PDF, we estimate or just use a placeholder if we can't extract text easily client side before sending.
    // The model will analyze content. We can ask the model to estimate word count or just default.
    // We will pass a prompt asking for metrics.
  }

  const prompt = `
    You are an advanced academic plagiarism checker engine. 
    Analyze the provided document content against your knowledge and the Google Search tool results.
    
    Your task is to generate a structured JSON assessment of the plagiarism level.
    
    1. Perform a search to check for copied content.
    2. Estimate a "Similarity Score" (0 to 100) based on how much text appears to be copied or unoriginal.
    3. Assign a Grade based on similarity: 
       - 0-10%: "A" (Satisfactory)
       - 11-40%: "B" (Upgrade)
       - 41-60%: "C" (Poor)
       - 61-100%: "D" (Unacceptable)
    4. Estimate a source breakdown (must sum to 100%) for:
       - "studentPapers" (typical academic phrasing or common student errors)
       - "publications" (formal academic sources)
       - "internet" (general web content)
    5. Provide a brief analysis text summarizing the findings.

    OUTPUT FORMAT:
    Return ONLY a raw JSON object. Do not include markdown formatting (like \`\`\`json).
    Structure:
    {
      "similarityScore": number,
      "grade": "A" | "B" | "C" | "D",
      "breakdown": { "studentPapers": number, "publications": number, "internet": number },
      "analysis": "string",
      "wordCount": number (estimate if PDF, or count provided text)
    }
  `;

  const parts = [];
  
  if (isBase64Pdf) {
    parts.push({
      inlineData: {
        mimeType: 'application/pdf',
        data: content
      }
    });
  } else {
    parts.push({ text: `CONTENT TO ANALYZE:\n${content}` });
  }
  
  parts.push({ text: prompt });

  // We cannot use responseMimeType: 'application/json' easily with tools in all cases, 
  // but we can ask for it. 
  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  let jsonString = response.text || "{}";
  // Clean markdown if present
  jsonString = jsonString.replace(/```json/g, '').replace(/```/g, '').trim();

  let parsedData;
  try {
    parsedData = JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to parse JSON response", e);
    // Fallback
    parsedData = {
      similarityScore: 0,
      grade: 'A',
      breakdown: { studentPapers: 0, publications: 0, internet: 0 },
      analysis: "Analysis could not be structured. See raw sources.",
      wordCount: isBase64Pdf ? 0 : wordCount
    };
  }
  
  // Extract grounding chunks (sources)
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  
  const sources: GroundingSource[] = [];

  chunks.forEach((chunk: any) => {
    if (chunk.web?.uri) {
      sources.push({
        title: chunk.web.title || "Web Source",
        uri: chunk.web.uri
      });
    }
  });

  // Deduplicate sources based on URI
  const uniqueSources = Array.from(new Map(sources.map(s => [s.uri, s])).values());

  return {
    similarityScore: parsedData.similarityScore || 0,
    grade: parsedData.grade || 'A',
    matchedSourcesCount: uniqueSources.length,
    wordCount: parsedData.wordCount || (isBase64Pdf ? 2500 : wordCount), // Default estimate if missing
    breakdown: parsedData.breakdown || { studentPapers: 0, publications: 0, internet: 0 },
    analysis: parsedData.analysis || "No specific analysis provided.",
    sources: uniqueSources
  };
};