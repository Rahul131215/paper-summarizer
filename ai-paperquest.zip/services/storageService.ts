import { HistoryItem, SummaryResult, PlagiarismResult } from '../types';

const STORAGE_KEY = 'paperquest_history';

export const saveHistoryItem = (
  type: 'SUMMARY' | 'PLAGIARISM',
  data: SummaryResult | PlagiarismResult,
  title: string,
  fileName?: string
): HistoryItem => {
  const history = getHistory();
  
  const newItem: HistoryItem = {
    id: crypto.randomUUID(),
    type,
    title: title || (fileName ? fileName : `Untitled ${type === 'SUMMARY' ? 'Summary' : 'Report'}`),
    date: new Date().toISOString(),
    data,
    fileName,
    previewText: type === 'SUMMARY' 
      ? (data as SummaryResult).abstract.substring(0, 100) + '...'
      : `Similarity Score: ${(data as PlagiarismResult).similarityScore}%`
  };

  const updatedHistory = [newItem, ...history];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedHistory));
  return newItem;
};

export const getHistory = (): HistoryItem[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const deleteHistoryItem = (id: string): HistoryItem[] => {
  const history = getHistory();
  const updated = history.filter(item => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

export const clearHistory = () => {
  localStorage.removeItem(STORAGE_KEY);
};

export const getStats = () => {
  const history = getHistory();
  const summaries = history.filter(h => h.type === 'SUMMARY');
  const reports = history.filter(h => h.type === 'PLAGIARISM');
  
  return {
    totalDocs: history.length,
    summariesCount: summaries.length,
    reportsCount: reports.length,
    lastActivity: history.length > 0 ? new Date(history[0].date).toLocaleDateString() : 'N/A'
  };
};