import React, { useState, useEffect } from 'react';
import { Menu, Book } from 'lucide-react';
import { AppMode, User, HistoryItem } from './types';
import { SummarizerTab } from './components/SummarizerTab';
import { PlagiarismTab } from './components/PlagiarismTab';
import { LandingPage } from './components/LandingPage';
import { AuthModal } from './components/AuthModal';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedHistoryItem, setSelectedHistoryItem] = useState<HistoryItem | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Check for existing session
  useEffect(() => {
    const savedUser = localStorage.getItem('paperquest_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('paperquest_user', JSON.stringify(userData));
    setShowAuthModal(false);
    setMode(AppMode.DASHBOARD);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('paperquest_user');
    setMode(AppMode.DASHBOARD);
  };

  // Handle navigation
  const handleNavigate = (newMode: AppMode, item?: HistoryItem) => {
    setMode(newMode);
    if (item) {
      setSelectedHistoryItem(item);
    } else {
      setSelectedHistoryItem(null);
    }
    setIsSidebarOpen(false); // Close sidebar on mobile when navigating
  };

  // Render Landing Page if not logged in
  if (!user) {
    return (
      <>
        <LandingPage onGetStarted={() => setShowAuthModal(true)} />
        <AuthModal 
          isOpen={showAuthModal} 
          onClose={() => setShowAuthModal(false)} 
          onLogin={handleLogin}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900 flex">
      
      {/* Sidebar Navigation */}
      <Sidebar 
        user={user}
        currentMode={mode}
        onModeChange={(m) => handleNavigate(m)}
        onLogout={handleLogout}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-72 transition-all duration-300 w-full">
        
        {/* Mobile Header */}
        <header className="lg:hidden bg-white border-b border-slate-200 h-16 flex items-center justify-between px-4 sticky top-0 z-30 shadow-sm">
          <div className="flex items-center gap-3">
             <button 
               onClick={() => setIsSidebarOpen(true)}
               className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
             >
               <Menu className="w-6 h-6" />
             </button>
             <div className="flex items-center gap-2">
                <div className="bg-primary-600 p-1.5 rounded-lg">
                  <Book className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-slate-900">PaperQuest</span>
             </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs">
            {user.name.charAt(0).toUpperCase()}
          </div>
        </header>

        <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-fade-in-up">
            {/* View Title (Desktop Only - specific views) */}
            {mode !== AppMode.DASHBOARD && (
               <div className="mb-8 hidden lg:block">
                 <h1 className="text-3xl font-bold text-slate-900">
                   {mode === AppMode.SUMMARIZER ? 'Research Intelligence' : 'Originality Verification'}
                 </h1>
                 <p className="text-slate-500 mt-1">
                   {mode === AppMode.SUMMARIZER 
                    ? 'Generate comprehensive summaries from academic texts.' 
                    : 'Check documents for potential plagiarism and citations.'}
                 </p>
               </div>
            )}

            {/* Views */}
            {mode === AppMode.DASHBOARD && (
              <Dashboard user={user} onNavigate={handleNavigate} />
            )}
            
            {mode === AppMode.SUMMARIZER && (
              <SummarizerTab 
                initialData={selectedHistoryItem} 
                onBack={() => handleNavigate(AppMode.DASHBOARD)} 
              />
            )}
            
            {mode === AppMode.PLAGIARISM_CHECKER && (
              <PlagiarismTab 
                user={user}
                initialData={selectedHistoryItem}
                onBack={() => handleNavigate(AppMode.DASHBOARD)}
              />
            )}
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 mt-auto bg-white/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 py-6 text-center text-slate-400 text-sm">
            <p>Powered by Google Gemini 2.5 Flash &bull; AI PaperQuest &copy; {new Date().getFullYear()}</p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;