export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  SUMMARIZER = 'SUMMARIZER',
  PLAGIARISM_CHECKER = 'PLAGIARISM_CHECKER',
}

export interface SummaryResult {
  abstract: string;
  keyFindings: string[];
  methodology: string;
  conclusion: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface PlagiarismResult {
  similarityScore: number; // 0-100
  grade: 'A' | 'B' | 'C' | 'D';
  matchedSourcesCount: number;
  wordCount: number;
  breakdown: {
    studentPapers: number;
    publications: number;
    internet: number;
  };
  analysis: string;
  sources: GroundingSource[];
}

export interface UploadedFile {
  name: string;
  type: string;
  data: string; // Base64
}

export interface User {
  email: string;
  name: string;
}

export interface HistoryItem {
  id: string;
  type: 'SUMMARY' | 'PLAGIARISM';
  title: string;
  date: string; // ISO string
  data: SummaryResult | PlagiarismResult;
  fileName?: string;
  previewText?: string; // For dashboard list view
}